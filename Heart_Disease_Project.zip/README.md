# Heart Disease Prediction Project

Comprehensive ML pipeline using the UCI Heart Disease dataset.